/////////////////////////////////////////////////////////////////
// タイピングゲームを作るのに必要なプラグイン TaipiLeed.js
// Copyright (c) 2022 fuobaa
// 
// このプラグインだけでは使えません。
// サンプルプロジェクトと一緒に使って下さい。
// 不明点等あれば fuobaa@Twitterまで 2022.02.06
/////////////////////////////////////////////////////////////////
/*:
 * @target MZ
 * @plugindesc タイピングゲームを作るのに必要なプラグイン
 * @author fuobaa
 * 
 * @param resetSwitch1
 * @text 戦闘終了後リセットするスイッチ１
 * @desc スイッチNoを入力(0で無効)
 * @max 999
 * @min 0
 * @type number
 * @default 11
 * 
 * @param resetSwitch2
 * @text 戦闘終了後リセットするスイッチ２
 * @desc スイッチNoを入力(0で無効)
 * @max 999
 * @min 0
 * @type number
 * @default 12
 * 
*/
(() => {
  const parameters = PluginManager.parameters('TaipiLeed');
  const swno1 = eval(parameters['resetSwitch1'] || '11');
  const swno2 = eval(parameters['resetSwitch2'] || '12');

    //////////////////////////////////////////////////
    // 入力受付文字の定義
    //////////////////////////////////////////////////
    Input.keyMapper[8] = 'back';
    Input.keyMapper[65] = 'A';
    Input.keyMapper[66] = 'B';
    Input.keyMapper[67] = 'C';
    Input.keyMapper[68] = 'D';
    Input.keyMapper[69] = 'E';
    Input.keyMapper[70] = 'F';
    Input.keyMapper[71] = 'G';
    Input.keyMapper[72] = 'H';
    Input.keyMapper[73] = 'I';
    Input.keyMapper[74] = 'J';
    Input.keyMapper[75] = 'K';
    Input.keyMapper[76] = 'L';
    Input.keyMapper[77] = 'M';
    Input.keyMapper[78] = 'N';
    Input.keyMapper[79] = 'O';
    Input.keyMapper[80] = 'P';
    Input.keyMapper[81] = 'Q';
    Input.keyMapper[82] = 'R';
    Input.keyMapper[83] = 'S';
    Input.keyMapper[84] = 'T';
    Input.keyMapper[85] = 'U';
    Input.keyMapper[86] = 'V';
    Input.keyMapper[87] = 'W';
    Input.keyMapper[88] = 'X';
    Input.keyMapper[89] = 'Y';
    Input.keyMapper[90] = 'Z';
    Input.keyMapper[188] = ',';
    Input.keyMapper[189] = '-';
    Input.keyMapper[190] = '.';
    Input.keyMapper[191] = '/';
    Input.keyMapper[222] = '^';

    Input.keyMapper[48] = '0';
    Input.keyMapper[49] = '1';
    Input.keyMapper[50] = '2';
    Input.keyMapper[51] = '3';
    Input.keyMapper[52] = '4';
    Input.keyMapper[53] = '5';
    Input.keyMapper[54] = '6';
    Input.keyMapper[55] = '7';
    Input.keyMapper[56] = '8';
    Input.keyMapper[57] = '9';

    Input.keyMapper[16] = 'shift';
    Input.keyMapper[32] = 'space';
    Input.keyMapper[219] = '[';
    Input.keyMapper[221] = ']';

    //////////////////////////////////////////////////
    // 変数の参照が面倒でつい作ってしまった罪深い関数
    //////////////////////////////////////////////////
    hen = function(hidx) {
        return $gameVariables.value(hidx);
    };

    //////////////////////////////////////////////////
    // 入力された文字列をひらながに変換するすごい関数
    //////////////////////////////////////////////////
    keyNihongo = function (getStr){
        var putStr = getStr;
        var keymap1 = {
            a:'あ',i:'い',u:'う',e:'え',o:'お',"-":'ー',".":'。',",":'、'
        };
        var keymap2 = {
            ka:'か',ki:'き',ku:'く',ke:'け',ko:'こ', ca:'か',cu:'く',co:'こ',
            sa:'さ',si:'し',su:'す',se:'せ',so:'そ', ci:'し',ce:'せ',
            ta:'た',ti:'ち',tu:'つ',te:'て',to:'と',
            na:'な',ni:'に',nu:'ぬ',ne:'ね',no:'の',
            ha:'は',hi:'ひ',hu:'ふ',he:'へ',ho:'ほ',
            ma:'ま',mi:'み',mu:'む',me:'め',mo:'も',
            ya:'や',yu:'ゆ',yo:'よ',
            ra:'ら',ri:'り',ru:'る',re:'れ',ro:'ろ',
            ga:'が',gi:'ぎ',gu:'ぐ',ge:'げ',go:'ご',
            za:'ざ',zi:'じ',zu:'ず',ze:'ぜ',zo:'ぞ',
            da:'だ',di:'ぢ',du:'づ',de:'で',do:'ど',
            ba:'ば',bi:'び',bu:'ぶ',be:'べ',bo:'ぼ',
            pa:'ぱ',pi:'ぴ',pu:'ぷ',pe:'ぺ',po:'ぽ',
            wa:'わ',  wi:'うぃ', wu:'う',  we:'うぇ',wo:'を',
            ye:'いぇ',qa:'くぁ', qi:'くぃ',qu:'く',  qe:'くぇ', qo:'くぉ',
            nk:'んk',ns:'んs',nc:'んc',nt:'んt',nh:'んh',nm:'んm',
            nr:'んr',nw:'んw',nq:'んq',np:'んp',nb:'んb',nx:'んx',
            nd:'んd',ng:'んg',nz:'んz',nj:'んj',
            nn:'ん', "n-":'んー',"n,":'ん、',"n.":'ん。',
            la:'ぁ',li:'ぃ',lu:'ぅ',le:'ぇ',lo:'ぉ',
            xa:'ぁ',xi:'ぃ',xu:'ぅ',xe:'ぇ',xo:'ぉ',
            va:'ヴぁ',vi:'ヴぃ',vu:'ヴ',  ve:'ヴぇ',vo:'ヴぉ',
            fa:'ふぁ',fi:'ふぃ',fu:'ふ',  fe:'ふぇ',fo:'ふぉ',
            ja:'じゃ',ji:'じ',  ju:'じゅ',je:'じぇ',jo:'じょ',
            kk:'っk',ss:'っs',tt:'っt',hh:'っh',mm:'っm',
            yy:'っy',rr:'っr',gg:'っg',zz:'っz',dd:'っd',ff:'っf',
            bb:'っb',pp:'っp',qq:'っq',cc:'っc',ll:'っl',xx:'っx',
        };
        var keymap3 = {
            gya:'ぎゃ',gyi:'ぎぃ',gyu:'ぎゅ',gye:'ぎぇ',gyo:'ぎょ',
            zya:'じゃ',zyi:'じぃ',zyu:'じゅ',zye:'じぇ',zyo:'じょ',
            dya:'ぢゃ',dyi:'ぢぃ',dyu:'ぢゅ',dye:'ぢぇ',dyo:'ぢょ',
            bya:'びゃ',byi:'びぃ',byu:'びゅ',bye:'びぇ',byo:'びょ',
            pya:'ぴゃ',pyi:'ぴぃ',pyu:'ぴゅ',pye:'ぴぇ',pyo:'ぴょ',
            kya:'きゃ',kyi:'きぃ',kyu:'きゅ',kye:'きぇ',kyo:'きょ',
            sya:'しゃ',syi:'しぃ',syu:'しゅ',sye:'しぇ',syo:'しょ',
            tya:'ちゃ',tyi:'ちぃ',tyu:'ちゅ',tye:'ちぇ',tyo:'ちょ',
            nya:'にゃ',nyi:'にぃ',nyu:'にゅ',nye:'にぇ',nyo:'にょ',
            hya:'ひゃ',hyi:'ひぃ',hyu:'ひゅ',hye:'ひぇ',hyo:'ひょ',
            mya:'みゃ',myi:'みぃ',myu:'みゅ',mye:'みぇ',myo:'みょ',
            rya:'りゃ',ryi:'りぃ',ryu:'りゅ',rye:'りぇ',ryo:'りょ',
            wyi:'ゐ',  wye:'ゑ',  wha:'うぁ',whi:'うぃ',whu:'う',  whe:'うぇ', who:'うぉ', lwa:'ゎ',
            jya:'じゃ',jyi:'じぃ',jyu:'じゅ',jye:'じぇ',jyo:'じょ',
            lya:'ゃ',  lyi:'ぃ',  lyu:'ゅ',  lye:'ぇ',  lyo:'ょ',  ltu:'っ',
            tsu:'つ',  shi:'し',  shu:'しゅ',she:'しぇ',sho:'しょ',sha:'しゃ',
            cha:'ちゃ',chi:'ち',  chu:'ちゅ',che:'ちぇ',cho:'ちょ',
            cya:'ちゃ',cyi:'ちぃ',cyu:'ちゅ',cye:'ちぇ',cyo:'ちょ',
            vya:'ヴゃ',vyi:'ヴぃ',vyu:'ヴゅ',vye:'ヴぇ',vyo:'ヴょ',
            xka:'ヵ',  xya:'ゃ',  xyi:'ぃ',  xyu:'ゅ',  xye:'ぇ',  xyo:'ょ', xtu:'っ', xwa:'ゎ',
        };
        var keymap4 = {
            ltsu:'っ', xtsu:'っ',
        };
        var key1 = "";
        var key2 = "";
        var key3 = "";
        var key4 = "";
        if (putStr.length >= 4) {
            if (putStr.slice(-4) in keymap4) {
                key4 = keymap4[putStr.slice(-4)];
                putStr = putStr.slice(0,-4) + key4;
                return putStr;
            }
        }
        if (putStr.length >= 3) {
            if (putStr.slice(-3) in keymap3) {
                key3 = keymap3[putStr.slice(-3)];
                putStr = putStr.slice(0,-3) + key3;
                return putStr;
            }
        }
        if (putStr.length >= 2) {
            if (putStr.slice(-1) == '<') {
                // BackSpace
                return putStr.slice(0,-2);
            }
            if (putStr.slice(-2) in keymap2) {
                key2 = keymap2[putStr.slice(-2)];
                putStr = putStr.slice(0,-2) + key2;
                return putStr;
            }
        }
        if (putStr.length >= 1) {
            if (putStr.slice(-1) == '<') {
                // BackSpace
                return putStr.slice(0,-1);
            }
            if (putStr.slice(-1) in keymap1) {
                key1 = keymap1[putStr.slice(-1)];
                putStr = putStr.slice(0,-1) + key1;
                return putStr;
            }
        }

        return getStr;
    };

    //////////////////////////////////////////////////
    // 入力されたキー情報を文字として返してくれるいい感じの関数
    //////////////////////////////////////////////////
    keyInputString = function(){
        if (Input.isTriggered('A') && Input.isPressed('shift')) return "Ａ";
        if (Input.isTriggered('B') && Input.isPressed('shift')) return "Ｂ";
        if (Input.isTriggered('C') && Input.isPressed('shift')) return "Ｃ";
        if (Input.isTriggered('D') && Input.isPressed('shift')) return "Ｄ";
        if (Input.isTriggered('E') && Input.isPressed('shift')) return "Ｅ";
        if (Input.isTriggered('F') && Input.isPressed('shift')) return "Ｆ";
        if (Input.isTriggered('G') && Input.isPressed('shift')) return "Ｇ";
        if (Input.isTriggered('H') && Input.isPressed('shift')) return "Ｈ";
        if (Input.isTriggered('I') && Input.isPressed('shift')) return "Ｉ";
        if (Input.isTriggered('J') && Input.isPressed('shift')) return "Ｊ";
        if (Input.isTriggered('K') && Input.isPressed('shift')) return "Ｋ";
        if (Input.isTriggered('L') && Input.isPressed('shift')) return "Ｌ";
        if (Input.isTriggered('M') && Input.isPressed('shift')) return "Ｍ";
        if (Input.isTriggered('N') && Input.isPressed('shift')) return "Ｎ";
        if (Input.isTriggered('O') && Input.isPressed('shift')) return "Ｏ";
        if (Input.isTriggered('P') && Input.isPressed('shift')) return "Ｐ";
        if (Input.isTriggered('Q') && Input.isPressed('shift')) return "Ｑ";
        if (Input.isTriggered('R') && Input.isPressed('shift')) return "Ｒ";
        if (Input.isTriggered('S') && Input.isPressed('shift')) return "Ｓ";
        if (Input.isTriggered('T') && Input.isPressed('shift')) return "Ｔ";
        if (Input.isTriggered('U') && Input.isPressed('shift')) return "Ｕ";
        if (Input.isTriggered('V') && Input.isPressed('shift')) return "Ｖ";
        if (Input.isTriggered('W') && Input.isPressed('shift')) return "Ｗ";
        if (Input.isTriggered('X') && Input.isPressed('shift')) return "Ｘ";
        if (Input.isTriggered('Y') && Input.isPressed('shift')) return "Ｙ";
        if (Input.isTriggered('Z') && Input.isPressed('shift')) return "Ｚ";
        if (Input.isTriggered('/') && Input.isPressed('shift')) return "？";

        if (Input.isTriggered('1') && Input.isPressed('shift')) return "！";
        if (Input.isTriggered('2') && Input.isPressed('shift')) return "”";
        if (Input.isTriggered('3') && Input.isPressed('shift')) return "＃";
        if (Input.isTriggered('4') && Input.isPressed('shift')) return "＄";
        if (Input.isTriggered('5') && Input.isPressed('shift')) return "％";
        if (Input.isTriggered('6') && Input.isPressed('shift')) return "＆";
        if (Input.isTriggered('7') && Input.isPressed('shift')) return "’";
        if (Input.isTriggered('8') && Input.isPressed('shift')) return "（";
        if (Input.isTriggered('9') && Input.isPressed('shift')) return "）";
        if (Input.isTriggered('^') && Input.isPressed('shift')) return "～";
        if (Input.isTriggered('0') && Input.isPressed('shift')) return "";

        if (Input.isTriggered('1')) return "１";
        if (Input.isTriggered('2')) return "２";
        if (Input.isTriggered('3')) return "３";
        if (Input.isTriggered('4')) return "４";
        if (Input.isTriggered('5')) return "５";
        if (Input.isTriggered('6')) return "６";
        if (Input.isTriggered('7')) return "７";
        if (Input.isTriggered('8')) return "８";
        if (Input.isTriggered('9')) return "９";
        if (Input.isTriggered('0')) return "０";
        if (Input.isTriggered('^')) return "＾";

        if (Input.isTriggered('A')) return "a";
        if (Input.isTriggered('B')) return "b";
        if (Input.isTriggered('C')) return "c";
        if (Input.isTriggered('D')) return "d";
        if (Input.isTriggered('E')) return "e";
        if (Input.isTriggered('F')) return "f";
        if (Input.isTriggered('G')) return "g";
        if (Input.isTriggered('H')) return "h";
        if (Input.isTriggered('I')) return "i";
        if (Input.isTriggered('J')) return "j";
        if (Input.isTriggered('K')) return "k";
        if (Input.isTriggered('L')) return "l";
        if (Input.isTriggered('M')) return "m";
        if (Input.isTriggered('N')) return "n";
        if (Input.isTriggered('O')) return "o";
        if (Input.isTriggered('P')) return "p";
        if (Input.isTriggered('Q')) return "q";
        if (Input.isTriggered('R')) return "r";
        if (Input.isTriggered('S')) return "s";
        if (Input.isTriggered('T')) return "t";
        if (Input.isTriggered('U')) return "u";
        if (Input.isTriggered('V')) return "v";
        if (Input.isTriggered('W')) return "w";
        if (Input.isTriggered('X')) return "x";
        if (Input.isTriggered('Y')) return "y";
        if (Input.isTriggered('Z')) return "z";
        if (Input.isTriggered('-')) return "-";
        if (Input.isTriggered(',')) return ",";
        if (Input.isTriggered('.')) return ".";
        if (Input.isTriggered('back')) return "<";
        if (Input.isTriggered('ok')) return "enter";
        if (Input.isTriggered('space')) return "　";
        if (Input.isTriggered('[')) return "「";
        if (Input.isTriggered(']')) return "」";
        return "";
    }


    //////////////////////////////////////////////////
    // 指定された文字列が全部含まれるか考えてくれる関数
    //////////////////////////////////////////////////
    mgchk = function ( vno, ...mgstr ) {
        for (strget of mgstr) {
            if(hen(vno).indexOf(strget) == -1) {
                return false;
            }
        }
        return true;
    }

//////////////////////////////////////////////////
// ボタン定義をいじる Zキーの調整
//////////////////////////////////////////////////
Game_Player.prototype.triggerButtonAction = function() {
    if (Input.isTriggered("ok") || Input.isTriggered("z")) {
//    if (Input.isTriggered("ok")) {
        if (this.getOnOffVehicle()) {
            return true;
        }
        this.checkEventTriggerHere([0]);
        if ($gameMap.setupStartingEvent()) {
            return true;
        }
        this.checkEventTriggerThere([0, 1, 2]);
        if ($gameMap.setupStartingEvent()) {
            return true;
        }
    }
    return false;
};

//////////////////////////////////////////////////
// 文字列""の時の変数の調整
//////////////////////////////////////////////////
Game_Variables.prototype.value = function(variableId) {
if (this._data[variableId] === "") {
  return "";
}

    return this._data[variableId] || 0;
};


//////////////////////////////////////////////////
// 無理やりエラーをなくす調整
//////////////////////////////////////////////////
BattleManager.startAction = function() {
    const subject = this._subject;
    const action = subject.currentAction();
    var targets;
try {
targets = action.makeTargets();
} catch (error) {
  console.error(error);
  return;
}

    this._phase = "action";
    this._action = action;
    this._targets = targets;
    subject.cancelMotionRefresh();
    subject.useItem(action.item());
    this._action.applyGlobal();
    this._logWindow.startAction(subject, action, targets);
};

   var _BattleManager_processVictory = BattleManager.processVictory;
   BattleManager.processVictory = function() {
        if ( 0 < swno1 ) {
            $gameSwitches.setValue(swno1,false);
        }
        if ( 0 < swno2 ) {
            $gameSwitches.setValue(swno2,false);
        }

      _BattleManager_processVictory.call(this);
   };


})();
