タイピングRPGのサンプルプロジェクトです。

RPGツクールMZの規約、及び使用プラグインの規約に従っている限り、
ご自由にお使い下さい。

<使用プラグイン>

トリアコンタン 様
    PluginCommonBase.js
    ExtraWindow.js

名無し蛙 様
    BattleParallelEvent.js

フオ婆
    TaipiLeed.js
